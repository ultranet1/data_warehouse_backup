''' # IMPORT NECESSARY LIBRARIES
'''
# Import airflow library 
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable 
# add library path
import sys
sys.path.insert(0, "/usr/local/airflow/.local/lib/python3.7/site-packages")
# Import Library to access databases from MongoDB (Middleware and VAS)
import pymongo
import urllib.parse
from pymongo import MongoClient
# import libraries (to access TAMS)
import psycopg2 as psy
import sqlalchemy
from sqlalchemy import create_engine
# import pandas for data transaformation
import pandas as pd
# import utility libraries
import numpy as np
import datetime
import os
from datetime import timedelta
import shutil
import sys
sys.path.insert(0, "/usr/local/airflow/.local/bin")


''' # AIRFLOW CONFIGURATION
'''
start_now = datetime.datetime(2022,4,12)
default_args = {
    'owner' : 'ITEX_dev_Alaran_Ibrahim',
    "depends_on_past" : False,
    "start_date"      : start_now,
    "retries"         : 2
     }
dag = DAG(dag_id='transactions_pipeline', catchup=False, schedule_interval='1 */1 * * *', default_args=default_args)

''' # FUNCTION TO EXTRACT DATA FROM VAS DB
'''
def extract_from_vas():
    host = "192.168.0.35"
    port = 11001
    user_name = "vasuser"
    pass_word = "p@$$w0rd@1"
    db_name = "vas"
    client = MongoClient(f'mongodb://{user_name}:{urllib.parse.quote_plus(pass_word)}@{host}:{port}/{db_name}')
    db = client['vas']
    start = datetime.datetime.utcnow()
    stop= start - timedelta(hours = 1)
    print('extracting data from vas for ' + str(stop.strftime('%Y-%m-%d %H:%M:%S')))
    result = db.vas_transaction.find({"updated_at": {"$gt": stop,
            "$lt": start}})
    df =  pd.DataFrame(list(result))
    df.columns = map(str.lower, df.columns)
    df['vas_source'] = 'yes'
    if not os.path.exists('/usr/local/airflow/transactions/vas'):
        os.makedirs('/usr/local/airflow/transactions/vas')
        df.to_csv('/usr/local/airflow/transactions/vas/' + str(start.strftime('%Y-%m-%d %H:%M:%S')) + '.csv')
        print('Extraction done ' + str(start.strftime('%Y-%m-%d %H:%M:%S')))
    else:
        df.to_csv('/usr/local/airflow/transactions/vas/' + str(start.strftime('%Y-%m-%d %H:%M:%S')) + '.csv')
        print('Extraction done ' + str(start.strftime('%Y-%m-%d %H:%M:%S')))

''' # FUNCTION TO EXTRACT DATA FROM MDW DB
'''
def extract_from_mdw():
    # middleware credentials
    host = "197.253.19.75"
    port = 22002
    user_name = "dataeng"
    pass_word = "4488qwe"
    db_name = "admin"
    client = MongoClient(f'mongodb://{user_name}:{urllib.parse.quote_plus(pass_word)}@{host}:{port}/{db_name}')
    db = client['eftEngine']
    start = datetime.datetime.utcnow()
    stop= start - timedelta(hours = 1)
    print('extracting data from middleware for ' + str(stop.strftime('%Y-%m-%d %H:%M:%S')))
    result = db.journals_22_04_06.find({"transactionTime": {"$gt": stop,
            "$lt": start}})
    df =  pd.DataFrame(list(result))
    df.columns = map(str.lower, df.columns)
    df['mdw_source'] = 'yes'
    if not os.path.exists('/usr/local/airflow/transactions/mdw'):
        os.makedirs('/usr/local/airflow/transactions/mdw')
        df.to_csv('/usr/local/airflow/transactions/mdw/' + str(start.strftime('%Y-%m-%d %H:%M:%S')) + '.csv')
        print('Extraction done ' + str(start.strftime('%Y-%m-%d %H:%M:%S')))
    else:
        df.to_csv('/usr/local/airflow/transactions/mdw/' + str(start.strftime('%Y-%m-%d %H:%M:%S')) + '.csv')
        print('Extraction done ' + str(start.strftime('%Y-%m-%d %H:%M:%S')))

''' # FUNCTION TO EXTRACT DATA FROM TAMS DB
'''
def extract_from_tams():
    start = datetime.datetime.now()
    # TAMS CREDENTIALS
    engine_source = create_engine('postgresql://admin:tams@192.168.0.134:5432/tams')
    print('extracting data from tams...')
    tams_merchant_df = pd.read_sql('SELECT * FROM merchant', con=engine_source)  
    tams_nodetype_df = pd.read_sql('SELECT * FROM nodetype', con=engine_source)
    tams_nodetype_df['mht_ntp_irn'] = tams_nodetype_df['ntp_irn']
    tams_balance_df = pd.read_sql('SELECT * FROM balance', con=engine_source)
    tams_balance_df['mht_irn'] = tams_balance_df['bal_mht_irn']
    
    # join dfs
    print('joining dataframes...')
    tams_merchant_df = tams_merchant_df.merge(tams_nodetype_df, on='mht_ntp_irn', how='left') 
    print('joining df1 and df2...')
    tams_merchant_df = tams_merchant_df.merge(tams_balance_df, on='mht_irn', how='outer')
    
    # save first part of profile
    if not os.path.exists('/usr/local/airflow/dimensions/profile'):
        os.makedirs('/usr/local/airflow/dimensions/profile')
        tams_merchant_df.to_csv('/usr/local/airflow/dimensions/profile/' + str(start.strftime('%Y-%m-%d %H:%M:%S')) + '.csv')
        print('Extraction done for profile 1 ' + str(start.strftime('%Y-%m-%d %H:%M:%S')))
    else:
        tams_merchant_df.to_csv('/usr/local/airflow/dimensions/profile/' + str(start.strftime('%Y-%m-%d %H:%M:%S')) + '.csv')
        print('Extraction done for profile 1 ' + str(start.strftime('%Y-%m-%d %H:%M:%S')))

''' # LOAD VAS TRANSACTIONS TO DATA WAREHOUSE
'''
def load_vas_to_dwh():
    conn = psy.connect(dbname='data_warehouse', user='itex_user', password='ITEX2022', host='192.168.0.242', port='5432')
    engine = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
    conn.autocommit = True
    folder = os.listdir('/usr/local/airflow/transactions/vas/')
    for i in folder:
        if len(folder) > 0:
            print('folder contain a file')
            vas_df = pd.read_csv('/usr/local/airflow/transactions/vas/' + str(i)) 
            vas_df.reset_index(drop=True)
            print('The number of rows in data is ' + str(len(vas_df)))
            print('loading vas transactions to warehouse...')
            try:
                cursor = conn.cursor()
                print('creating vas_transactions table...')
                vas_df.to_sql('vas_transactions', engine, schema='galaxy_schema', if_exists='append', index=False, dtype={col_name: sqlalchemy.types.Text() for col_name in vas_df})
                print('Vas transaction loaded  to data warehouse ')

                # alter table to create vas_id, this will be use to create schema
                cursor = conn.cursor()
                cursor.execute("ALTER TABLE galaxy_schema.vas_transactions ADD COLUMN IF NOT EXISTS vas_id SERIAL PRIMARY KEY;")
                # Commit your changes in the database
                conn.commit()
                conn.close()
            except:
                engine = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
                print("Direct loading failed due to extra column, creating additional column")
                sql = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS \
                    WHERE table_name = 'vas_transactions'"
                tb_df = pd.read_sql(sql, con=engine)
                tb_ls = tb_df['column_name'].values.tolist()
                vas_ls= vas_df.columns.tolist()
                print('getting the extra columns')
                col_dif = set(vas_ls) - set(tb_ls)
                print(col_dif)
                col_dif2 = list(col_dif) 
                print(col_dif2)
                #Creating a cursor object using the cursor() method
                cursor = conn.cursor()
                print('creating columns in table') 
                for l in col_dif2:
                    cursor.execute('ALTER TABLE galaxy_schema.%s ADD COLUMN IF NOT EXISTS %s text' % ('vas_transactions', str(l)))        
                    # Commit your changes in the database
                    conn.commit()
                conn.close()
                print('retrying data load to table...')
                vas_df.to_sql('vas_transactions', engine, schema='galaxy_schema', if_exists='append', index=False,  dtype={col_name: sqlalchemy.types.Text() for col_name in vas_df})

                # alter table to create vas_id, this will be use to create schema
                cursor = conn.cursor()
                cursor.execute("ALTER TABLE galaxy_schema.vas_transactions ADD COLUMN IF NOT EXISTS vas_id SERIAL PRIMARY KEY;")
                # Commit your changes in the database
                conn.commit()
                conn.close()

        else:   
                
            print('folder is empty')

''' # LOAD MDW TRANSACTIONS TO DATA WAREHOUSE
'''
def load_mdw_to_dwh():
    conn = psy.connect(dbname='data_warehouse', user='itex_user', password='ITEX2022', host='192.168.0.242', port='5432')
    engine = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
    conn.autocommit = True
    folder = os.listdir('/usr/local/airflow/transactions/mdw/')
    for i in folder:
        if len(folder) > 0:
            print('folder contain a file')
            mdw_df = pd.read_csv('/usr/local/airflow/transactions/mdw/' + str(i))
            mdw_df.reset_index(drop=True)
            #mdw_df = mdw_df.drop('Unnamed: 0')
            print('The number of rows in data is ' + str(len(mdw_df)))
            print('loading mdw transactions to warehouse...')
            try:
                mdw_df.to_sql('mdw_transactions', engine,  schema='galaxy_schema', if_exists='append', index=False,  dtype={col_name: sqlalchemy.types.Text() for col_name in mdw_df})
                print('mdw transaction loaded  to data warehouse ')

                # alter table to create mdw_id, this will be use to create schema
                cursor = conn.cursor()
                cursor.execute("ALTER TABLE galaxy_schema.mdw_transactions ADD COLUMN IF NOT EXISTS mdw_id SERIAL PRIMARY KEY;")
                # Commit your changes in the database
                conn.commit()
                conn.close()
            except:
                engine = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
                print("Direct loading failed due to extra column, creating additional column")
                sql2 = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS \
                    WHERE table_name = 'mdw_transactions'"
                
                tb_df2 = pd.read_sql(sql2, con=engine)
                tb_ls2 = tb_df2['column_name'].values.tolist()
                mdw_ls= mdw_df.columns.tolist()
                print('getting the extra columns')
                col_dif2 = set(mdw_ls) - set(tb_ls2)
                print(col_dif2)
                col_dif2 = list(col_dif2) 
                print(col_dif2)
                #Creating a cursor object using the cursor() method
                cursor = conn.cursor()
                print('creating columns in table') 
                for l in col_dif2:
                    cursor.execute('ALTER TABLE galaxy_schema.%s ADD COLUMN IF NOT EXISTS %s text' % ('mdw_transactions', str(l)))        
                    # Commit your changes in the database
                    conn.commit()
                conn.close()
                print('retrying data load to table...')
                mdw_df.to_sql('mdw_transactions', engine,  schema='galaxy_schema', if_exists='append', index=False, dtype={col_name: sqlalchemy.types.Text() for col_name in mdw_df})

                # alter table to create mdw_id, this will be use to create schema
                cursor = conn.cursor()
                cursor.execute("ALTER TABLE galaxy_schema.mdw_transactions ADD COLUMN IF NOT EXISTS mdw_id SERIAL PRIMARY KEY;")
                # Commit your changes in the database
                conn.commit()
                conn.close()
        else:
            print('folder is empty')

''' # EXTRACT DATE DIMENSION FROM TRANSACTIONS (VAS AND MDW) AND LOAD TO DATA WAREHOUSE
'''
def date_dim():
    conn = psy.connect(dbname='data_warehouse', user='itex_user', password='ITEX2022', host='192.168.0.242', port='5432')
    engine = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
    conn.autocommit = True
    # extract data from vas in the past 1 hour
    vas_df = pd.read_sql_query('''SELECT * FROM galaxy_schema.vas_transactions WHERE TO_TIMESTAMP(updated_at,'YYYY-MM-DD HH24:MI:SS') \
                             BETWEEN NOW() - INTERVAL '1 HOUR' AND NOW() ORDER BY vas_id;''', con=engine)
    vas_df.reset_index(drop=True)
    # extract data from mdw in the past 1 hour
    mdw_df = pd.read_sql_query('''SELECT * FROM galaxy_schema.mdw_transactions WHERE TO_TIMESTAMP(transactiontime,'YYYY-MM-DD HH24:MI:SS') \
                             BETWEEN NOW() - INTERVAL '1 HOUR' AND NOW() ORDER BY mdw_id;''', con=engine)
    mdw_df.reset_index(drop=True)
    mdw_df['updated_at'] = mdw_df['transactiontime']
    mdw_df['terminal'] = mdw_df['terminalid']
    # append both df
    both_df1 = vas_df.append(mdw_df, ignore_index=True)
    both_df1.reset_index(drop=True)

    print('extracting date dimension from transaction...')
    date_dim_df = pd.DataFrame()
    date_dim_df['vas_source'] = both_df1['vas_source']
    date_dim_df['mdw_source'] = both_df1['mdw_source']
    date_dim_df['vas_date_irn'] = (pd.to_numeric(both_df1['vas_id'],errors='coerce')).astype('Int32')             
    date_dim_df['mdw_date_irn'] = (pd.to_numeric(both_df1['mdw_id'],errors='coerce')).astype('Int32')                   
    date_dim_df['datetime'] = both_df1['updated_at']
    date_dim_df['datetime'] = pd.to_datetime(date_dim_df['datetime'], dayfirst=True)
    date_dim_df['terminal_id'] = both_df1['terminal']
    date_dim_df['year'] = date_dim_df['datetime'].dt.year
    date_dim_df['month'] = date_dim_df['datetime'].dt.month
    date_dim_df['week_number'] = date_dim_df['datetime'].dt.week
    date_dim_df['day_of_year'] = date_dim_df['datetime'].dt.dayofyear
    date_dim_df['day_of_month'] = date_dim_df['datetime'].dt.day
    date_dim_df['week_day'] = date_dim_df['datetime'].dt.day_name()
    date_dim_df['time'] = date_dim_df['datetime'].dt.time
    date_dim_df['half'] = np.where(date_dim_df['datetime'].dt.month.le(6), '1st_half', '2nd_half')
    date_dim_df['quarter'] = date_dim_df['datetime'].dt.quarter
    date_dim_df['month'] = date_dim_df['datetime'].dt.month
    date_dim_df.reset_index(drop=True)

    print('The number of rows in data is ' + str(len(date_dim_df)))
    print('loading date dimensions to warehouse...')
    date_dim_df.to_sql('date_dim', engine, schema='galaxy_schema', if_exists='append', index=False)
    # dtype={col_name: sqlalchemy.types.VARCHAR for col_name in date_dim_df}
    print('date dim loaded  to data warehouse ')
    
    # alter table and add foreign keys constraint if not exists
    cursor = conn.cursor()
    '''
    try:
        cursor.execute("ALTER TABLE IF EXISTS galaxy_schema.date_dim ADD CONSTRAINT mdw_id_date_dim FOREIGN KEY (mdw_date_irn) \
                    REFERENCES galaxy_schema.mdw_transactions (mdw_id) MATCH SIMPLE ON UPDATE NO ACTION \
                        ON DELETE NO ACTION NOT VALID;")
    except:
        pass
    conn.commit()
    try:
        cursor.execute("ALTER TABLE IF EXISTS galaxy_schema.date_dim ADD CONSTRAINT vas_id_date_dim FOREIGN KEY (vas_date_irn) \
                    REFERENCES galaxy_schema.vas_transactions (vas_id) MATCH SIMPLE ON UPDATE NO ACTION \
                        ON DELETE NO ACTION NOT VALID;")
    except:
        pass
    conn.commit()
    conn.close()
    '''
''' # EXTRACT PRODUCT DIMENSION FROM TRANSACTIONS(VAS AND MDW) AND LOAD TO DATA WAREHOUSE
'''    
def product_dim():
    conn = psy.connect(dbname='data_warehouse', user='itex_user', password='ITEX2022', host='192.168.0.242', port='5432')
    engine = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
    conn.autocommit = True
    # extract data from vas in the past 1 hour
    vas_df = pd.read_sql_query('''SELECT * FROM galaxy_schema.vas_transactions WHERE TO_TIMESTAMP(updated_at,'YYYY-MM-DD HH24:MI:SS') \
                             BETWEEN NOW() - INTERVAL '1 HOUR' AND NOW() ORDER BY vas_id;''', con=engine)
    vas_df.reset_index(drop=True)
    print(vas_df)
    # extract data from mdw in the past 1 hour
    mdw_df = pd.read_sql_query('''SELECT * FROM galaxy_schema.mdw_transactions WHERE TO_TIMESTAMP(transactiontime,'YYYY-MM-DD HH24:MI:SS') \
                             BETWEEN NOW() - INTERVAL '1 HOUR' AND NOW() ORDER BY mdw_id;''', con=engine)
    mdw_df.reset_index(drop=True)
    print(mdw_df)
    mdw_df['updated_at'] = mdw_df['transactiontime']
    mdw_df['terminal'] = mdw_df['terminalid']
    mdw_df['product'] = mdw_df['transactiontype']
    mdw_df['productcodedata'] = mdw_df['ejournaldata']
    # append both df
    both_df10 = vas_df.append(mdw_df, ignore_index=True)
    both_df10.reset_index(drop=True)
    print('extracting product dim from transaction')
    product_dim = pd.DataFrame()
    print(both_df10.columns.values)
    product_dim['vas_product_irn'] = (pd.to_numeric(both_df10['vas_id'],errors='coerce')).astype('Int32')
    product_dim['mdw_product_irn'] = (pd.to_numeric(both_df10['mdw_id'],errors='coerce')).astype('Int32')
    product_dim['product_name'] = both_df10['product']
    product_dim['datetime'] = both_df10['updated_at']
    product_dim['terminal'] = both_df10['terminal']
    product_dim['product_data'] = both_df10['productcodedata']
    
    print('The number of rows in data is ' + str(len(product_dim)))
    print('loading date dimensions to warehouse...')
    product_dim.to_sql('products_dim', engine, schema='galaxy_schema', if_exists='append', index=False)
    # dtype={col_name: sqlalchemy.types.VARCHAR for col_name in date_dim_df}
    print('product dim loaded  to data warehouse ')
    
    '''
   # alter table and add foreign keys constraint if not exists
    cursor = conn.cursor()
    try:
        cursor.execute("ALTER TABLE galaxy_schema.products_dim ADD CONSTRAINT vas_id_prod_dim FOREIGN KEY (vas_product_irn) \
                        REFERENCES galaxy_schema.vas_transactions (vas_id) MATCH SIMPLE ON UPDATE NO ACTION \
                            ON DELETE NO ACTION NOT VALID;")
    except:
        pass
    conn.commit()
    try:
        cursor.execute("ALTER TABLE galaxy_schema.products_dim ADD CONSTRAINT mdw_id_prod_dim FOREIGN KEY (mdw_product_irn) \
                    REFERENCES galaxy_schema.mdw_transactions (mdw_id) MATCH SIMPLE ON UPDATE NO ACTION \
                        ON DELETE NO ACTION NOT VALID;")
    except:
        pass
    conn.commit()
    conn.close()
    '''


def profile_dim():
    start = datetime.datetime.now()
    # TAMS CREDENTIALS
    #conn_string = 'postgres://itex_user:ITEX2022@192.168.0.242/data_warehouse'
    engine1 = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
    engine_source = create_engine('postgresql://admin:tams@192.168.0.134:5432/tams')
    print('extracting data from tams...')
    tams_terminals_df = pd.read_sql('SELECT * FROM terminals', con=engine_source)
    tams_terminals_df['mht_irn'] = tams_terminals_df['trm_mht_irn']
    tams_terminals_df['tid'] = tams_terminals_df['trm_termid']
    # vas credentials
    host = "192.168.0.35"
    port = 11001
    user_name = "vasuser"
    pass_word = "p@$$w0rd@1"
    db_name = "vas"
    client = MongoClient(f'mongodb://{user_name}:{urllib.parse.quote_plus(pass_word)}@{host}:{port}/{db_name}')
    db = client['vas']
    # extract collections from vas
    print('extracting data from vas...')
    result = db.nqr_ptsp_merchants.find()
    nqr_ptsp_merchant_df =  pd.DataFrame(list(result))

    folder11 = os.listdir('/usr/local/airflow/dimensions/profile/')
    for i in folder11:
        if len(folder11) > 0:
            print('folder contain a file')
            tams_merchant_df = pd.read_csv('/usr/local/airflow/dimensions/profile/' + str(i)) 
            tams_merchant_df.reset_index(drop=True)

    print('joining df3 and df4...')
    tams_merchant_df = tams_merchant_df.merge(tams_terminals_df, on='mht_irn', how='outer')
    print('joining df5 and df6...')
    tams_nqr_ptsp_merchant_df = tams_merchant_df.merge(nqr_ptsp_merchant_df, on='tid', how='outer')
    
    print('The number of rows in data is ' + str(len(tams_nqr_ptsp_merchant_df)))
    print('splitting dataframe into 100...')
     
    # Drop existing profile db, and load current one
    conn = psy.connect(database="data_warehouse", user='itex_user', password='ITEX2022', host='192.168.0.242', port= '5432')
    conn.autocommit = True
    cursor = conn.cursor()
    cursor.execute('''DROP TABLE IF EXISTS galaxy_schema.profiles_dim ''')
    print("Table dropped !")
    conn.commit()
    conn.close()

    # loading all profile data to warehouse crash airflow, split data and load in chunks
    for start in range(0, len(tams_nqr_ptsp_merchant_df), 4000):
        small_df = tams_nqr_ptsp_merchant_df[start:start+4000]
        cols = list(tams_nqr_ptsp_merchant_df.columns.values)
        small_df = pd.DataFrame(small_df, columns=cols )
        print('changing column types to strings...')
        #print(small_df)
        
        small_df = small_df.astype(str)
        print('loading dataframe ' + str(start) + ' to data warehouse')
        small_df.to_sql('profiles_dim', con=engine1, schema='galaxy_schema', if_exists='append', index=False, dtype={col_name: sqlalchemy.types.VARCHAR for col_name in tams_nqr_ptsp_merchant_df})
    print('profile dim loaded  to data warehouse ')    

''' # EXTRACT LOCATION DIMENSION FROM PROFILE DIMENSION AND LOAD TO DATA WAREHOUSE
'''
def location_dim():
    # TAMS CREDENTIALS
    engine_dwh = create_engine('postgresql://itex_user:ITEX2022@192.168.0.242:5432/data_warehouse')
    engine_tams = create_engine('postgresql://admin:tams@192.168.0.134:5432/tams')
    
    #extract tables
    profiles_dim_df = pd.read_sql('SELECT mht_irn, mht_name, mht_addr, mht_code, mht_addrcity, mht_addrstate FROM galaxy_schema.profiles_dim', engine_dwh) 
    print(profiles_dim_df)
    tams_states_df = pd.read_sql('SELECT * FROM states;', engine_tams)
    tams_region_df = pd.read_sql('SELECT reg_irn, reg_name, reg_city FROM regions;', engine_tams)
    #tams_region_df['reg_irn'] = tams_region_df['mht_reg_irn']
    tams_cities_df = pd.read_sql('SELECT * FROM cities;', engine_tams)

    # join all dataframes
    location_df = pd.DataFrame()
    profiles_dim_df['stn_code'] = profiles_dim_df['mht_addrstate']
    location_df = profiles_dim_df.merge(tams_states_df, on = 'stn_code', how = 'left')
    location_df['ctn_stn_code'] = location_df['stn_code']
    print(location_df)
    
    print('The number of rows in data is ' + str(len(location_df)))
    print('loading location dimensions to warehouse...')
    location_df.to_sql('location_dim', engine_dwh, schema='galaxy_schema', if_exists='replace', index=False)
    # dtype={col_name: sqlalchemy.types.VARCHAR for col_name in date_dim_df}
    print('location dim loaded  to data warehouse ')

''' # CLEAN ALL FILES PER BATCH RUN
'''
def clean_all():
    folder = os.listdir('/usr/local/airflow')
    if os.path.exists('/usr/local/airflow/transactions'):
        folder = os.listdir('/usr/local/airflow')
        print(folder)
        shutil.rmtree('/usr/local/airflow/transactions')
        folder = os.listdir('/usr/local/airflow')
        print(folder)
    else:
        pass
    if os.path.exists('/usr/local/airflow/dimensions'):
        folder = os.listdir('/usr/local/airflow')
        print(folder)
        shutil.rmtree('/usr/local/airflow/dimensions')
        folder = os.listdir('/usr/local/airflow')
        print(folder)
    else:
        pass 

t1 = PythonOperator(task_id = 'extract1',
    python_callable=extract_from_vas,
    dag=dag)

t2 = PythonOperator(task_id='extract2',
    python_callable=extract_from_mdw,
    dag=dag)

t3 = PythonOperator(task_id = 'load1',
    python_callable=load_vas_to_dwh,
    dag=dag)

t4 = PythonOperator(task_id='load2',
    python_callable=load_mdw_to_dwh,
    dag=dag)

t5 = PythonOperator(task_id='clean',
    python_callable=clean_all,
    dag=dag)

t6 = PythonOperator(task_id='load_to_date_dim',
    python_callable=date_dim,
    dag=dag)

t7 = PythonOperator(task_id='load_to_product_dim',
    python_callable=product_dim,
    dag=dag)

t8 = PythonOperator(task_id='extract_to_profile_dim',
    python_callable=extract_from_tams,
    dag=dag)

t9 = PythonOperator(task_id='load_to_profile_dim',
    python_callable=profile_dim,
    dag=dag)

t10 = PythonOperator(task_id='load_to_location_dim',
    python_callable=location_dim,
    dag=dag)

t5 >> t1 >> t3 
t5 >> t2 >> t4

[t3, t4] >> t6
[t3, t4] >> t7
[t3, t4, t6, t7] >> t8

t8 >> t9
t9 >> t10
#t3 >> t7 
#t4 >> t7

